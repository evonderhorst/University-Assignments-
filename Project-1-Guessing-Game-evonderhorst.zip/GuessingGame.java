/**
Erich Vonderhorst
Project 1
COSC 117
10/07/2022

This program is a single-player game in which the player enters a range of numbers and must choose which one the program randomly selected. The program will tell the user if their guess was correct, higher or lower than the number chosen. The program also checks for valid input when receiving the minimum and maximum values for the guessing range and for the guesses made by the user.
*/
import java.util.Scanner;
class GuessingGame {
  public static void main(String[] args) {
    Scanner stdin = new Scanner(System.in);
    while (true) {
      int min = 0; //Variable to store minimum value of quessing range
      int max = 0; //Variable to store maximum value of guessing range
      boolean win = false; //Variable used to determine if the user won
      boolean lose = false; //Variable used to determine if the useer lost
      boolean quit = false; //Variable used to determine if the user wants to play again or not
      //Getting min value from user
      while (true) {
        System.out.print("Enter the minimum value: ");
        //Checking for valid integers
        if (stdin.hasNextInt()) {
          min = stdin.nextInt();
          if (min < 0) {
            System.out.println("Value cannot be negative.");
            stdin.nextLine();
          }
          else {
            break;
          }
        }
        else {
          System.out.println("Enter a valid integer.");
          stdin.nextLine();
        }
      }
      //Getting max value from user
      while (true) {
        System.out.print("Enter the maximum value that is at least ten greater than the minimum: ");
        //Checking for valid integers and if the range is large enough to play
        if (stdin.hasNextInt()) {
          max = stdin.nextInt();
          if (max - min <= 9) {
            System.out.print("Value must be at least ten greater than the minimum.\n");
            stdin.nextLine();
          }
          else {
            stdin.nextLine();
            break;
          }
        }
        else {
          System.out.println("Enter a valid integer.");
          stdin.nextLine();
        }
      }
      //Generating the computer's random selection in the range given
      int selection = (int) (Math.random() * ((max + 1) - min) + min);
      int guesses = (max - min) / 2; //Variable for number of guesses based on the range given
      if (guesses > 10) { //Maximizing the number of guesses
        guesses = 10;
      }
      //Difficulty selection
      while (true) {
        System.out.println("Please enter the number of the difficulty you want to play at: 1 for hard, 2 for medium, or 3 for easy: ");
        if (stdin.hasNextInt()) {
          int difficulty = stdin.nextInt();
          //Hard difficulty
          if (difficulty == 1) {
            guesses = guesses/2; //Hard gets half the normal amount of guesses
            break;
          }
          //Medium difficulty
          else if (difficulty == 2) {
            break; //Medium gets the normal amount of guesses
          }
          //Easy difficulty
          else if (difficulty == 3) {
            guesses += (guesses/2); //Easy gets 50% more than the normal amount of guesses
            break;
          }
          else {
            System.out.println("Please enter a valid number for a difficulty.");
          }
        }
        else {
          System.out.println("Please enter a valid number for a difficulty.");
          stdin.nextLine();
        }
      }
      stdin.nextLine();
      //Main game loop
      for (int x = guesses; x > 0; x--) {
        System.out.println("Please guess the number the computer selected in your range. You have " + x + " guesses left: ");
        //Checking for valid input
        if (stdin.hasNextInt()) {
          int userGuess = stdin.nextInt();
          //If guess is right
          if (userGuess == selection ) {
            int guessesMade = (guesses + 1) - x;//Varaible for the total guesses made by the user
            System.out.println("Congratulations! You guessed right in only " + guessesMade + " tries!");  
            win = true;
            break;
          }
          //If guess is wrong
          else if (userGuess != selection) {
            //Checking to see if there are any guesses left
            if (x == 1) {
              System.out.println("Sorry! You ran out of guesses. You lose!");
              lose = true;
              break;
            }
            //Checking whether the user's guess was lower or higher than the computer's selection
            else {
              //Higher
              if (userGuess > selection) {
                System.out.println("Your guess was higher than the computer's selection. Try again.");
                stdin.nextLine();
              }
              //Lower
              else {
                System.out.println("Your guess was lower than the computer's selection. Try again.");
                stdin.nextLine();
              }
            }
          }
          else {
            System.out.println("Please guess a valid integer.");
            stdin.nextLine();
          }
        }
        else{
          System.out.println("Please guess a valid integer");
          stdin.nextLine();
        }
      }
      //Asking the user if they want to play again
      stdin.nextLine();
      while (true) {
        System.out.println("Would you like to play again? Enter 1 for yes or 2 for no: ");
        if (stdin.hasNextInt()) {
          int answer = stdin.nextInt();
          //Play again
          if (answer == 1) {
            break;
          }
          //Quit
          else if (answer == 2) {
            quit = true;
            break;
          }
          else {
            System.out.println("Please enter 1 for yes or 2 for no.");
            stdin.nextLine();
          }
        }
        else {
          System.out.println("Please enter 1 for yes or 2 for no.");
          stdin.nextLine();
        }
      }
      if (quit == true) {
        break;
      }
      else {
        continue;
      }
    }
  }
} 