# Count pairs with given sum
## Overview
Read in an array, up to 20 integers long, which contain elements from 1 to 100. If the user inputs a 0 or negative number, you can assume they are done giving input.

Write a program that can find pairs of numbers in the array that add up to a given **sum**. You should read this target **sum** from the standard input as well.

Print out each pair you find that adds up to the given sum.

**A specific array index cannot be a pair with itself**

## Example 1
```
Enter a target sum...
11
Enter up to 20 integers between 0 to 100 (0 stops)...
2
9
4
3
8
6
7
0
======
Calculating pairs...
======
Pair found! 2 9
Pair found! 4 7
Pair found! 3 8
======
Number of pairs found: 3
```
