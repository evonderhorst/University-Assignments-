/**
Erich Vonderhorst
Lab 5 Problem 2
COSC 117
10/10/2022

This program looks for pairs of numbers in an array of integers input by the user whose sum is equal to a separate value input by the user. 
*/
import java.util.Scanner;
class Pairs {
  public static void main(String[] args) {
    Scanner stdin = new Scanner(System.in);
    int count = 0; //Variable used to keep track of number of integers entered by user
    int targValue = 0; //Variable to store target value
    int[] integers = new int[20]; //Array used to store integers entered by user
    int value = 0; //Variable used to enter numbers into the array for integers
    int[] sumsOne = new int[200]; //Array used to store first number in integer pair adding up to the target value
    int[] sumsTwo = new int[200]; //Array used to store second number in integer pair adding up to target value
    int sumCount = 0; //Variable used to keep track of the number of integer pairs found
    int sum = 0; //Variable used to hold some of numbers being checked
    //Getting a target sum
    System.out.println("Enter a target sum that is an integer between 2 and 200: ");
    while (true) {
      if (stdin.hasNextInt()) {
        targValue = stdin.nextInt();
        if (targValue < 2 || targValue > 200) {
          System.out.println("Please enter a value between 2 and 200. ");
          stdin.nextLine();
        }
        else {
          break;
        }
      }
      else {
        System.out.println("Please enter a valid integer. ");
        stdin.nextLine();
      }
    }
    //Getting integers from user
    System.out.println("Please enter up to 20 integers between 0 and 100. Enter a value outside of that range to stop: ");
    while (true) {
      if (stdin.hasNextInt()) {
        value = stdin.nextInt();
        if (value < 0 || value > 100) {
          break;
        }
        else {
          integers[count] = value;
          count++;
          if (count == 20) {
            break;
          }
        }
      }
      else {
        System.out.println("Please enter a valid integer. ");
        stdin.nextLine();
      }
    }
    //Looking for sums
    for ( int i = 0; i < count; i++) {
      for (int x = i + 1; x< count; x++) {
        sum = integers[i] + integers[x];
        if (sum == targValue) {
          sumsOne[sumCount] = integers[i];
          sumsTwo[sumCount] = integers[x];
          sumCount++;
        }
      }
    }
    //Outputting results
    System.out.println("Number of pairs found: " + sumCount);
    if (sumCount > 0) {
      System.out.println("The pairs found were: ");
      for (int y = 0; y < sumCount; y++) {
        System.out.println(sumsOne[y] + " + " + sumsTwo[y]);
      }
    }
    stdin.close();
  }
}