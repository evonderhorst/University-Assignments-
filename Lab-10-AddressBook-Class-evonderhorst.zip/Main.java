// DO NOT MODIFY THIS FILE 
class Main {
  public static void main(String[] args) {
    // Load address book from file
    AddressBook book = new AddressBook("addresses.txt");
    // Display the number of contacts in the address book
    System.out.println("Number of contacts: " + book.getContactCount());
    // Add a new contact from the standard input
    book.addContact();
    // Display the new number of contacts in the address book
    System.out.println("Number of contacts: " + book.getContactCount());
    // Display current address book
    book.print();
    // Remove a contact
    book.remove("Tony Stark");
    // Display current address book
    book.print();
    // Save the contact book to a new file
    book.save("new.txt");
  }
}
