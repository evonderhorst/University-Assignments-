class Contact {
  public String firstName;
  public String lastName;
  public int age;
  public String phone;
  public String address;
  
/**
Constructor pseudocode:
  -Given a first and last name, age, phone number, address
  -save each parameter to a corresponding instance variable
*/
  public Contact(String name1, String name2, int years, String number, String street) {
    this.firstName = name1;
    this.lastName = name2;
    this.age = years;
    this.phone = number;
    this.address = street;
  }
  
/**
Print function pseudocode:
    -print first and last name of contact instance
    -print age of contact instance
    -print phone number of contact instance
    -print address of contact instance
  */
  public void print() {
    System.out.println("Name: " + this.firstName + " " + this.lastName);
    System.out.println("Age: " + this.age);
    System.out.println("Cell: " + this.phone);
    System.out.println("Address: " + this.address);
  }
}