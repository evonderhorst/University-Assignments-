import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

class AddressBook {
  // The current list of contacts
  public Contact[] contacts;
  // The number of contacts we currently store
  public int nContacts;
  // The maximum number of contacts our addressbook can store
  public static final int MAX_CONTACTS = 100;
  // Filename the addressbook lives in
  public String filename;
  // Stdin scanner
  Scanner stdin;

/**
Constructor pseudocode:
  -Declare a variable for each parameter needed to create a new contact instance
  -Safely open a scanner in the file specified by the constructor's parameter with a try catch statement
  -Assuming the information in each line follows the same order (name then address then phone number etc.) read each line using the scanner and assign it to an instance variable
  -Create a new contact instance to the address book instance's contact array using all the newly acquired instance variables as parameters
  -Call the addContact(Contact) method using the newly created contact instance as a parameter
*/
  public AddressBook(String filename) {
    this.contacts = new Contact[MAX_CONTACTS];
    try {
      stdin = new Scanner(new File(filename));
      String firstName = "";
      String lastName = "";
      int age;
      String phone;
      String address;
    
      while (stdin.hasNextLine()) {
        firstName = stdin.next();
        lastName = stdin.next();
        age = stdin.nextInt();
        phone = stdin.next();
        address = stdin.nextLine();
        address += stdin.next();
        address += stdin.nextLine();
        Contact addition = new Contact(firstName,lastName,age,phone,address);
        addContact(addition);  
      }
    }
    catch (FileNotFoundException e) {
      System.out.println("File not found!");
    }
    stdin.close();
  }

/**
Integer reader pseudocode:
  -Given a string parameter representing a prompt (tells the user what they are assigning)
  -Use prompt parameter in a print statement asking the user to assign an integer to that value
  -Loop until broken:
    -Check if the next line of the standard input is an integer
      -If is an integer, check to see if it is positive
        -If not negative, break the loop
        -If negative, refresh the scanner with nextLine() and restart the loop
      -If not an integer, refresh the scanner with nextLine() and restart the loop
  -Return the integer read from the standard input to the method
*/
  public int readInt(String prompt) {
    int value = 0;
    stdin = new Scanner(System.in);
    System.out.print(prompt + ": ");
    while (true) {
      if (stdin.hasNextInt()) {
        value = stdin.nextInt();
        if (value <= 0) {
          stdin.nextLine();
        }
        else{
          break;
        }
      }
      else{
        System.out.print(prompt + ": ");
        stdin.nextLine();
      }
    }
    return value;
  }

/**
Contact adding pseudocode:
  -Declare a variable for each parameter needed to create a new contact instance
  -Ask the user for each value and assign their input to each variable, use the readInt method when assigning a value to the age variable
  -Create a new contact using the newly assigned variables as parameters
  -Call the addContact(Contact) method using the newly created contact instance as a parameter
*/
  public void addContact() {
    stdin = new Scanner(System.in);
    String firstName;
    String lastName;
    int age;
    String phone;
    String address;
    System.out.print("First name: ");
    firstName = stdin.nextLine();
    System.out.print("Last name: ");
    lastName = stdin.nextLine();
    age = readInt("Age");
    System.out.print("Number: ");
    stdin.nextLine();
    phone = stdin.nextLine();
    System.out.print("Address: ");
    address = stdin.nextLine();
    Contact addition = new Contact(firstName,lastName,age,phone,address);
    addContact(addition);
    stdin.close();
  }
  
/**
Adding a contact parameter pseudocode:
  -Given an instance of a contact
  -Check to see if the maximum number of contacts has already been stored in the address book instance's array
  -If the maximum has been reached:
    -Print out an error message
  -If the maximum has not been reached:
    -Add the contact in the method's parameter to the address book instance's array
    -Increment the number of contacts for the current address book instance
  
*/
  public void addContact(Contact add) {
    if (this.nContacts == MAX_CONTACTS) {
      System.out.print("An address book cannot contain more than " + MAX_CONTACTS + " contacts.");
    }
    else {
      this.contacts[this.nContacts] = add;
      this.nContacts++;
    }
  }

/**
Getting the number of contacts pseudocode:
  -Return nContacts of the current address book instance
*/
  public int getContactCount() {
    return this.nContacts;
  }
  
/**
Saving contacts to a file pseudocode:
  -Given a file name
  -Safely instantiate a printwriter for the file with the name of the parameter using a try catch statement
  -Loop over every contact in the address book instance's array
    -Print each variable of the contact instance to the file using the printwriter
*/
  public void save(String filename) {
    try {
      PrintWriter stdout = new PrintWriter(filename);
      for (int x = 0; x < this.nContacts; x++) {
        stdout.println(this.contacts[x].firstName + " " + this.contacts[x].lastName);
        stdout.println(this.contacts[x].age);
        stdout.println(this.contacts[x].phone);
        stdout.println(this.contacts[x].address);
      }  
      stdout.close();
    }
    catch (FileNotFoundException e) {
      System.out.println("File not found!");
    }
  }

/**
Removing contacts from address book pseudocode:
  -Given a name
  -Create a count variable to determine the number of times a contact with the same name as the parameter occurs
  -Create a temporary contact array the length of the number of contacts of the current address book instance
  -Loop through each contact in the address book instance's contact array and concatenate the first and last name of each:
    -Check to see if the concatenated string is equal to the parameter
    -If it is:
      -Increment the count variable
    -If not:
      -Store the contact from the adress book instance's array with the index corresponding to the local variable into the the temporary array
  -Loop through each contact stored in the temporary contact array:
    -Set the contact of the address book instance's array corresponding to the index of the local variable to that of the temporary array
  -Subtract the count variable from the number of contacts for the current address book instance
*/ 
  public void remove(String name) {
    int count = 0;
    Contact[] temp = new Contact[nContacts]; 
    for (int x = 0; x < this.nContacts; x++) {
      String fullName = this.contacts[x].firstName + " " + this.contacts[x].lastName;
      if (fullName.equals(name) == true) {
        count++;
      }
      else {
        temp[x - count] = this.contacts[x];
      }
    }
    for (int y = 0; y < temp.length; y++) {
      this.contacts[y] = temp[y];
    }
    this.nContacts -= count;
  }
  
/**
Printing out address book pseudocode:
  -Loop over every contact in the address book instance's contact array
    -Use print method defined in Contact.java for each contact in the array
*/
  public void print() {
    System.out.println("===================");
    System.out.println("Contact list: " + this.nContacts);
    System.out.println("===================");
    for (int x = 0; x < this.nContacts; x++) {
      this.contacts[x].print();
      System.out.println();
    }
  }
}