# Instructions  
Complete the program. 

You have two taasks
- Create pseudocode for each function mentioned in the specifications
  - With detailed input / output
  - Pseudocode for the functionality
- Complete the program/classes by implementing your plan / pseudocode.

If you write the functions to the specification, the program will run as expected.

# Specifications
This program is meant to model the concept of an "Address Book". A book that stores all of your contacts. 

There is a contact class that represents a single contact in your book. It should contain the following data and functionality

Contact.java
```
Data belonging to each contact
- (Strings) Contact's first and last name
- (int) Contact's age
- (String) Contact's phone number
- (String) Contact's address

======== Functions ========
- A constructor that takes in all of the values as parameters, and stores them in the class instance.
- print() - Print out the contact's data
```

AddressBook.java
```
======== Functions ========
- Constructor that has a filename parameter, initializes all class variables, and reads each contact from the file into instances of the Contact class. Then storing them in our address book.

- readInt(String) - A helper function that reads in an integer from the command line and handles erroneous output for us. The function should take in a String parameter for its prompt. This function should return the integer that it reads in from standard input.

- addContact() - Creates a new contact based on data read from the standard input, and adds it to the contact book.

- addContact(Contact) - adds a new contact(passed to the function) to the contact book

- getContactCount() - Returns the number of contacts in the address book

- save(filename) - Saves the current address book to the filename passed to the function. It should be saved in the same format as addresses.txt.

- remove(name) - Removes a contact from the address book if the contact's name matches the passed name.

- print() - Print out the address book
```

# Hints
- Use the properties defined in AddressBook.
- Use the concept of partially full arrays to manage the contacts stored in the address book
- Use the addContact(Contact) function when reading in from the file
- Use function overloading for the addContact function.
- Only use one instance of the scanner for reading from the standard input. 


# Example run
```
Number of contacts: 4
Adding new contact...
First name: ARandom
Last name: Student
Age: 19
Number: 888-777-6666
Address: 1101 Camden Ave, Salisbury, MD 21801
Number of contacts: 5
====================
Contact list: 5
====================
Name: Tony Stark
Age: 48
Cell: 333-333-3333
Address: 1200 Industrial Ave, Long Beach, CA 90803

Name: Bruce Banner
Age: 39
Cell: 222-222-2222
Address: Somewhere down south

Name: Bruce Wayne
Age: 48
Cell: 111-111-1111
Address: 1007 Mountain Drive, Gotham

Name: Luke Skywalker
Age: 20
Cell: 555-555-5555
Address: Somewhere far far away

Name: ARandom Student
Age: 19
Cell: 888-777-6666
Address: 1101 Camden Ave, Salisbury, MD 21801

====================
Contact list: 4
====================
Name: ARandom Student
Age: 19
Cell: 888-777-6666
Address: 1101 Camden Ave, Salisbury, MD 21801

Name: Bruce Banner
Age: 39
Cell: 222-222-2222
Address: Somewhere down south

Name: Bruce Wayne
Age: 48
Cell: 111-111-1111
Address: 1007 Mountain Drive, Gotham

Name: Luke Skywalker
Age: 20
Cell: 555-555-5555
Address: Somewhere far far away
```

# Example run 2 (With integer input checking)
## The terminal I/O
```
Number of contacts: 4
Adding new contact...
First name: ARandom 
Last name: Student
Age: hello
Age: world
Age: 20
Number: 888-777-6666
Address: 1101 Camden Ave, Salisbury, MD 21801
Number of contacts: 5
====================
Contact list: 5
====================
Name: Tony Stark
Age: 48
Cell: 333-333-3333
Address: 1200 Industrial Ave, Long Beach, CA 90803

Name: Bruce Banner
Age: 39
Cell: 222-222-2222
Address: Somewhere down south

Name: Bruce Wayne
Age: 48
Cell: 111-111-1111
Address: 1007 Mountain Drive, Gotham

Name: Luke Skywalker
Age: 20
Cell: 555-555-5555
Address: Somewhere far far away

Name: ARandom Student
Age: 20
Cell: 888-777-6666
Address: 1101 Camden Ave, Salisbury, MD 21801

====================
Contact list: 4
====================
Name: ARandom Student
Age: 20
Cell: 888-777-6666
Address: 1101 Camden Ave, Salisbury, MD 21801

Name: Bruce Banner
Age: 39
Cell: 222-222-2222
Address: Somewhere down south

Name: Bruce Wayne
Age: 48
Cell: 111-111-1111
Address: 1007 Mountain Drive, Gotham

Name: Luke Skywalker
Age: 20
Cell: 555-555-5555
Address: Somewhere far far away
```

## The file output
```
ARandom Student
20
888-777-6666
1101 Camden Ave, Salisbury, MD 21801
Bruce Banner
39
222-222-2222
Somewhere down south
Bruce Wayne
48
111-111-1111
1007 Mountain Drive, Gotham
Luke Skywalker
20
555-555-5555
Somewhere far far away
```