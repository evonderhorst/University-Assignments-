/**
Lab 3
Erich Vonderhorst
COSC 117
09/26/2022

This program practices more complex array operations in java by creating a program to
calculate the hypothetical profit gained from salsa sales.
*/
import java.util.Scanner;
class Salsa {
  public static void main(String[] args) {
    //1. Setting the Arrays
    String[] flavors = { //salsa flavor array
      "mild",       //
      "medium",     //
      "hot",        //2. Initiation List
      "sweet",      //
      "zesty"       //
    };
    int[] sales = { //array for number of each flavor sold, same order as the flavors array
      0,            //
      0,            //
      0,            //2. Initiation List
      0,            //
      0             //
    };
    double[] prices = { //array for the price of each flavor, same order as the flavors array
      1.11,         //
      2.22,         //
      3.33,         //2. Initiation List
      4.44,         //
      5.55          //
    };
    //3. User Prompt
    Scanner prompt = new Scanner(System.in);
    for (int x=0; x<5; x++) {
      System.out.print("Enter the amount of " + flavors[x] + " salsas sold ($" + prices[x] + " each): ");
      sales[x] = prompt.nextInt();
    }
    //4. Sales Report and Calculations
    double gross = 0;
    for (int y=0; y<5; y++) {
      double total = prices[y] * sales[y];
      gross += total;
    }
    double tax = gross * 0.06;
    double net = gross - tax;
    System.out.format("%-5s %.2f\n","Gross: ",gross);
    System.out.format("%-7s %.2f\n","Tax: ",tax);
    System.out.format("%-7s %.2f\n","Net: ",net);
  }
}