class Main {
  public static void main(String[] args) {
    
    //First Test Student: Erich
    Student Erich = new Student();
    Erich.studentName = "Erich";
    Erich.addClass("COSC 117", 0.01);
    Erich.addClass("ENGL 103", 0.84);
    Erich.addClass("HIST 101", 0.75);
    Erich.studentMajor = "Computer Science";
    Erich.studentYear = "Freshman";
    Erich.studentEmail = "evonderhorst1@gulls.salisbury.edu";
    Erich.printInfo();

    //Second Test Student: Every Computer Science Major
    Student ECSM = new Student("Every Computer Science Major");
    ECSM.studentMajor = "Computer Science";
    ECSM.studentEmail = "everycompscimajor@gmail.com";
    ECSM.studentYear = "All";
    //Testing Array Resizing by Adding a Number of Classes that Excedes the Initial Maximum Index
    ECSM.addClass("Depression",1.00);
    ECSM.addClass("Sleep",0.00);
    ECSM.addClass("Stack Overflow",1.00);
    ECSM.addClass("Why isn't my program working?!",1.00);
    ECSM.addClass("Forgetting the ';' at the end",0.75);
    ECSM.addClass("Caffeine addiction",1.00);
    ECSM.printInfo();
    //Please laugh :(
    
    //Third Test Student: Jesus
    Student Jesus = new Student("Jesus");
    Jesus.studentMajor = "Miracle Performing";
    Jesus.studentYear = "Senior";
    Jesus.studentEmail = "j3$u$d@$@vior83@heavenmail.com";
    Jesus.addClass("Disciple teaching",1.00);
    Jesus.addClass("Turning water into wine",1.00);
    Jesus.addClass("Walking on water",1.00);
    Jesus.addClass("Healing the sick",1.00);
    Jesus.addClass("Feeding 5,000",1.00);
    Jesus.addClass("Spending 40 days in the desert",1.00);
    Jesus.addClass("Satan defiance",1.00);
    Jesus.addClass("Crucifixion",1.00);
    Jesus.addClass("Resurrection",1.00);
    Jesus.addClass("Salvation",1.00);
    Jesus.printInfo();

    //Printing out Total Number of Students Constructed
    System.out.println("Total Students Constructed: " + Student.totalStudents);

    //End of Tests
  }
}














































// Nothing to See Here.






















































//Why are you still scrolling? There's nothing down here!

























































//Stop wasting your time, you'll find nothing.































































//Don't you have anything better to do?


























































//Fine, keep on scrolling. See if I care.































































/**
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣤⣤⣤⣤⣤⣶⣦⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⡿⠛⠉⠙⠛⠛⠛⠛⠻⢿⣿⣷⣤⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠋⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠈⢻⣿⣿⡄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣸⣿⡏⠀⠀⠀⣠⣶⣾⣿⣿⣿⠿⠿⠿⢿⣿⣿⣿⣄⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⠁⠀⠀⢰⣿⣿⣯⠁⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣷⡄⠀
⠀⠀⣀⣤⣴⣶⣶⣿⡟⠀⠀⠀⢸⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣷⠀
⠀⢰⣿⡟⠋⠉⣹⣿⡇⠀⠀⠀⠘⣿⣿⣿⣿⣷⣦⣤⣤⣤⣶⣶⣶⣶⣿⣿⣿⠀
⠀⢸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀
⠀⣸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠉⠻⠿⣿⣿⣿⣿⡿⠿⠿⠛⢻⣿⡇⠀⠀
⠀⣿⣿⠁⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣧⠀⠀
⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀
⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀
⠀⢿⣿⡆⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀
⠀⠸⣿⣧⡀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠃⠀⠀
⠀⠀⠛⢿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⣰⣿⣿⣷⣶⣶⣶⣶⠶ ⢠⣿⣿⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⣽⣿⡏⠁⠀⠀⢸⣿⡇⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⢹⣿⡆⠀⠀⠀⣸⣿⠇⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢿⣿⣦⣄⣀⣠⣴⣿⣿⠁⠀⠈⠻⣿⣿⣿⣿⡿⠏⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⠛⠻⠿⠿⠿⠿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
*/