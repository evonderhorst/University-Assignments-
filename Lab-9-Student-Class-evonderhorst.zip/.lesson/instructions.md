# Instructions
This lab is meant to help you get experience in classes and functions.

## Student class
Write a class that will represent a `Student`. You should ensure the class has the following attributes
- name
- id
- email
- student year: freshman, sophomore, etc....
- major
- classes taken
- grades of their classes
- a variable to track the total number of students we've created

You should also implement the following behaviors in the Student class
- A default constructor that increments the total number of students
- Another constructor that **also** takes in the name of the student
- Calculating and returning the student's GPA
- A print function that prints the student information
- A function that takes in the name of a class, and the grade, then adds them to the classes taken and grades stored within the student
  
### Hint: Resizing arrays
If you go to add a new class/grade to the arrays, but there is no room left. Consider creating a new array, copying the data into it, and then adding the new data.


## Main class
You will still use the Main class and main function as an entry point for your program.

This will be where you create **instances** of your `Student` class and interact with them.

In your main code / testing, you should create at least 3 student instances with different names. 

