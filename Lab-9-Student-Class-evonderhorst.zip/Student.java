class Student {
  private static int nextId = 0; //Variable that stores the id of the next student instance constructed
  public String studentName; //Name of student instance (not the instance's   identifier)
  public int studentId; //Id of student instance
  public String studentEmail; //Email of student instance
  public String studentYear; //Year of student instance (freshman, sophomore, etc.)
  public String studentMajor; //Major of student instance
  public String[] classes = new String[5]; //Array for holding classes of student instance
  public double[] grades = new double[5]; //Array for holding grades of student instance
  public static int totalStudents = 0; //Value for total number of students created
  public int totalClasses = 0; //Variable that keeps track of the total number of classes entered for a student instance. Used for array indexing.
  
  //Default Constructor
  public Student() {
    this.studentId = nextId;
    nextId++;
    totalStudents++;
  }

  //Constructor That Takes in Student Name
  public Student(String name) {
    this.studentId = nextId;
    nextId++;
    this.studentName = name;
    totalStudents++;
  }

  //Function for Adding Classes and Grades
  public void addClass (String newClass, double newGrade) {
    try {
      this.classes[this.totalClasses] = newClass;
      this.grades[this.totalClasses] = newGrade;
    }
    catch (ArrayIndexOutOfBoundsException e) {
      this.classes = this.updateClassArray(newClass);
      this.grades = this.updateGradeArray(newGrade);
    }
    this.totalClasses++;
  }

  //Method for Resizing the Class Array for a Student Instance
  public String[] updateClassArray(String newClass) {
    String[] newClasses = new String[this.classes.length + 1];
    for (int x = 0; x < this.classes.length; x++) {
      newClasses[x] = this.classes[x];
    }
    newClasses[newClasses.length - 1] = newClass;
    return newClasses;
  }

  //Method for Resizing the Grade Array for a Student Instance
  public double[] updateGradeArray(double newGrade) {
    double[] newGrades = new double[this.grades.length + 1];
    for (int x = 0; x < this.grades.length; x++) {
      newGrades[x] = this.grades[x];
    }
    newGrades[newGrades.length - 1] = newGrade;
    return newGrades;
  }

  //Method for Printing Out Student Instance Information
  public void printInfo() {
    System.out.println("Name: " + this.studentName);
    System.out.println("ID: " + this.studentId);
    System.out.println("Year: " + this.studentYear);
    System.out.println("Email: " + this.studentEmail);
    System.out.println("Major: " + this.studentMajor);
    System.out.print("Classes and Grades: ");
    for (int x = 0; x < this.totalClasses; x++){
      System.out.print(this.classes[x] + " (" + this.grades[x] + "), ");
    }
    System.out.println("\nGPA: " + String.format("%.2f",this.getGPA()));
    System.out.println();
  }
  
  //Method for Calculating GPA
  public double getGPA() {
    double total = 0;
    for (int x = 0; x < this.totalClasses; x++) {
      if (this.grades[x] <= 1.00 && this.grades[x] >= 0.97) {
        total += 4.33;
      }
      else if (this.grades[x] <= 0.96 && this.grades[x] >= 0.93) {
        total += 4.00;
      }
      else if (this.grades[x] <= 0.92 && this.grades[x] >= 0.90) {
        total += 3.67;
      }
      else if (this.grades[x] <= 0.89 && this.grades[x] >= 0.87) {
        total += 3.33;
      }
      else if (this.grades[x] <= 0.86 && this.grades[x] >= 0.83) {
        total += 3.00;
      }
      else if (this.grades[x] <= 0.82 && this.grades[x] >= 0.80) {
        total += 2.67;
      }
      else if (this.grades[x] <= 0.79 && this.grades[x] >= 0.77) {
        total += 2.33;
      }
      else if (this.grades[x] <= 0.76 && this.grades[x] >= 0.73) {
        total += 2.00;
      }
      else if (this.grades[x] <= 0.72 && this.grades[x] >= 0.70) {
        total += 1.67;
      }
      else if (this.grades[x] <= 0.69 && this.grades[x] >= 0.67) {
        total += 1.33;
      }
      else if (this.grades[x] <= 0.66 && this.grades[x] >= 0.63) {
        total += 1.00;
      }
      else if (this.grades[x] <= 0.62 && this.grades[x] >= 0.60) {
        total += 0.67;
      }
      else {
        total += 0;
      }
    }
    return (total / this.totalClasses);
  }
}