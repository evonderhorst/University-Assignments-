# Lab 4
# 1. Objectives
1. Practice using standard input
2. Practice using loops and arrays

# 2. Tasks
1. Write a program that asks the user to input up to 20 positive integers and store each of them into an array; they can enter exactly 20, or enter a 0 when they are finished. If they enter exactly 20, the program should simply stop asking and continue with the standard process. Store each integer they enter into an array, and count how many they enter.
2. Print the total number of entries
3. Then print each of the entries, but in the reverse order in which they were entered. *Hint: How can you make the "standard" for-loop approach work backwards?*
4. Finally, display the average of all the integers entered.

# Example run 1
```
Enter up to 20 positive integers. Enter a 0 when you are finished.
3
65
71
3
6
5
0
You entered 6 integers. In reverse order, they were:
5
6
3
71
65
3
The average is: 25.5
```

# Example run 2
```
Enter up to 20 positive integers. Enter a 0 when you are finished.
3
9
-4
(try again) Please enter only positive integers
4
6
12
17
0
You entered 6 integers. In reverse order, they were:
17
12
6
4
9
3
The average is: 8.5
```

# 3. Turn in
Upload each .java file to the Canvas assignment for Lab 4.

Submit your code here on replit

# 4. Bonus
1. (5pts) add validation to make sure each input is a positive integer. If it is invalid, warn the user and allow them to enter another one.