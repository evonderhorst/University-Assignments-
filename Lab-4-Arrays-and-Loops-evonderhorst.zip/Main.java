/**
Erich Vonderhorst
Lab 4
COSC 117
10/03/2022

This program practices the use of standard input, loops, and arrays by asking the user to input
up to 20 positive integers to be stored into an array.
*/
import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner prompt = new Scanner(System.in);
    int counter = 0; //variable to keep track of entries
    int total = 0; //variable used in calculating the average
    int[] userInt = new int[20]; //array to store entries
    System.out.print("Enter up to 20 positive integers. Enter a 0 when you are finished. \n");
    //Taking and Storing Integers
    for (;;) {
      int value = prompt.nextInt();
      if (value < 0) {
        System.out.print("Integer is negative, try again. \n");
        continue;
      }
      else {
        if (value==0) {
          break;
        }
        else {
          userInt[counter] = value;
          counter++;
          if (counter == 20) {
            break;
          }
        }
      }
    }
    //Reverse Order and Average Output
    System.out.print("You entered " + counter + " integers. In reverse order, they were: \n");
    for (int x = counter-1; x > -1; x--) {
      System.out.print(userInt[x] + "\n");
      total += userInt[x];
    }
    float average = (float)total / (float)counter;
    System.out.print("The average is: " + average);
  }
}