/**
Erich Vonderhorst
Lab 6
COSC 117
10/17/2022

The purpose of this program is to practice using arrays, strings, user input, data types, and ASCII representations by translating certain text characters to symbols and by creating a simple cipher.
*/
import java.util.Scanner;
class Cipher {
  public static void main(String[] args) {
    Scanner stdin = new Scanner(System.in);
    char[] letters = {'a', 'e', 'l', 'o', 's', 't'}; //Array for letters that will be replaced
    char[] symbols = {'@', '3', '1', '0', '$', '7'}; //Replacement symbols for letters above
    int shift = 0; //Variable used to hold shift value given by user input
    //Getting a sentence from user input and making it lowercase
    System.out.println("Enter a lowercase sentence: ");
    String sentence = stdin.nextLine();
    sentence = sentence.toLowerCase();
    //Splitting sentence into an array, translating it to leetspeak, and outputting it
    char[] sentenceChars = sentence.toCharArray();
    for (int i = 0; i < sentenceChars.length; i++) {
      for (int x = 0; x < letters.length; x++) {
        if (sentenceChars[i] == letters[x]) {
          sentenceChars[i] = symbols[x];
        }
      }
    }
    for (int y = 0; y < sentenceChars.length; y++) {
      System.out.print(sentenceChars[y]);
    }
    //Getting a shift value for Caesar Cipher
    System.out.println("\nEnter a shift: ");
    while (true) {
      if (stdin.hasNextInt()) {
        shift = stdin.nextInt();
        if (shift < 0) {
          System.out.println("Shift can't be negative.");
          stdin.nextLine();
        }
        else {
          break;
        }
      }
      else {
        System.out.println("Enter a valid integer");
        stdin.nextLine();
      }
    }
    //Carrying out the cipher and converting characters
    sentenceChars = sentence.toCharArray();
    for (int z = 0; z < sentenceChars.length; z++) {
      if (sentenceChars[z] != ' ') {
        char eachChar = sentenceChars[z];
        int newChar = shift + (int)eachChar;
        //Wrapping around from z back to a
        while (newChar > 122) {
          newChar -= 26;
        }
        System.out.print(eachChar);
        System.out.print(" " + (int)eachChar); 
        System.out.print(" " + (char)newChar + "\n");
        sentenceChars[z] = (char)newChar;
      }
    }
    sentence = new String(sentenceChars);
    System.out.println("The Caesar Cipher (shift " + shift + ") is: " + sentence);
  }
}