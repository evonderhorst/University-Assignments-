/**
Lab 2 Problem 2
Erich Vonderhorst
Lab 1 - Problem 1
COSC 117
09/22/2022

This program practices the use of random variables, while loops, if statements, and logical operators. These components are used together to simulate dice rolls and recognize specific number combinations.

1. Pseudocode:

Declare two variables: nOne and nTwo for dice roll values 
Declare an integer to store a count
Loop while nOne != 1 and nTwo != 1
  Assign random integers to nOne and nTwo using Math.random
  Print out the values of nOne and nTwo side-by-side
  If nOne == 6 && nTwo == 6
    Print "Boxcars!"
  If (nOne == 5 && nTwo == 6) || (nOne == 6 && nTwo == 5)
    Print "Yo-level!"
Print the value for the total number of rolls

2. Snake Eyes Program
*/
class SnakeEyes {
  public static void main(String[] args) {
    int nOne = 0;
    int nTwo = 0;
    int counter = 0;
    while (true) {
      counter++;
      nOne = (int)(Math.random() * 6+1);
      nTwo = (int)(Math.random() * 6+1);
      System.out.print(nOne + " and " + nTwo + " \n");
      /**
      3. "Boxcars" and "Yo-level" Messages
      */
      if (nOne == 6 && nTwo == 6) {
        System.out.print("- Boxcars! \n");
      }
      if ((nOne == 5 && nTwo == 6) || (nOne == 6 && nTwo == 5)){
        System.out.print("- Yo-level! \n");
      }
      if (nOne == 1 && nTwo == 1){
        System.out.print("- Snake Eyes! You rolled " + counter + " times.");
        break;
      }
    }
  }
}
/**
4. In order for the user to choose the number of dice used in the experiment, a for loop would need to be created in order to generate a number of random integers equal to the amount of dice designated. The resulting integers could then be placed into an array and where the program can check if they are all ones through another for loop. Said for loop would check if each stored value is a one and if it is, it will scan the next and so on. A variable could be used to count the number of ones that are stored in the array and if it reaches a number equal to the amount of dice rolled, the program will output "Snake Eyes."

5. In order to simulate dice with more or less sides, the range of the random number assignments would be a variable given through user input. The program would prompt the user for the number of sides on both dice and store it as a variable. Said variable would then appear in the Math.random assignments to the two value varaibles: nOne and nTwo.
*/