# 1. Objectives
1. Practice using standard input
2. Practice basic arithmetic operations
3. Practice using loops and comparison
4. Practice random number generation
5. Practice using loops and comparison

# 2. Background
## Collatz Conjecture
The "3N+1" algorithm is the following procedure: given a positive integer, if it is even, divide it in half, and if not, multiply it by three and add one. Repeat this until the integer is equal to 1. The "Collatz Conjecture" asserts that this procedure will always halt, ending with the integer reduced to the number 1. However, nobody has ever been able to prove that this is true (that is, for certain "special" integers, the program might run forever)!

## Snake eyes
How many times do you have to roll a pair of dice before they come up snake eyes? You could do the experiment by rolling the dice by hand. The main idea is to maintain two different variables to represent the die rolls, which we can re-assign values every time the user needs to re-roll.

# 3. Tasks
## Collatz Conjecture
Create a class called "Collatz" and the file that contains it. This class should...

1. Ask the user to enter a positive integer.
2. Perform the following operations with the integer:
    - If the integer is even, divide it by two (use the modulus operator %)
    - If the integer is odd, multiply it by three and add one
    - Print the new integer to the screen
    - If the integer is still larger than 1, repeat the above steps. You will want to use a while loop for this!
3. Use an extra variable to count how many times the above procedure was repeated. Output the number of loops to the user. 

## Snake eyes
1. **Before you begin coding:** Draw by hand or with digital tools a flowchart for how you want your program to behave. Make sure you clearly label your conditionals, and add a description to each non-conditional block of code to say what will happen there.

2. Create a class called "SnakeEyes" and the file that contains it. The class should simulate rolling two dice and report the number of rolls that it makes before a pair of dice come up "snake eyes" (both roll a one).
    1. Use the java ``Math.random()`` function to generate a random number between 0 and 1 and then use that to (fairly) determine what number comes up on that die.
    2. Consider how to structure the main loop of the code: how will it look to check for a snake eyes?
    3. Make sure you re-roll the dice every time the loop runs, so that the program doesn't run forever!
3. In addition, report a message whenever the simualted dice roll is "boxcars" (both roll sixes) or "Yo-level" (one five and one six)
4. What if you wanted the user to be able to choose how many dice were used in the experiment? How much your program have to be changed?
5. What if you wanted to change the number of sides on teh dice? How about rolling 8 or 10 sided dice? How much would the code change to simulate this?

# 4. Submission
Download the zip file containing all of your code and upload it to the MyClasses assignment page for Lab 2 and submit the lab here on replit.

Any questions should be answered in the comments of the lab's source code file.