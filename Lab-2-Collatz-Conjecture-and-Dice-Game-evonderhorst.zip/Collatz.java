/**
Lab 2 Problem 1
Erich Vonderhorst 
COSC 117
09/22/2022

This program practices the use of user input via the scanner utility, while loops, if statements, and logical operators. These elements are combined to perform the calculations involved in the Collatz Conjecture based on a given integer.

Pseudocode:

Declare a variable to hold our N
Take in user input (integer) and store it in N
Declare an integer to store a count

loop while N != 1
  Print out whatever value N is holding
  if N is even
    assign N = N / 2
  other if N is odd
    assign N = 3 * N + 1
  increment count

Print out the value of N
*/
import java.util.Scanner;
class Collatz {
  public static void main(String[] args) {
    Scanner stdin = new Scanner(System.in);
    /**
    1. Asking the User for a Positive Integer
    */
    System.out.print("Enter a positive integer: ");
    int N = stdin.nextInt();
    /**
    3. Variable Used to Count the Number of Times Repeated
    */
    int counter = 0;
    /**
    2. Conjecture Calculations
    */
    while (N != 1) {
      if (N % 2 == 1) {
        N = (N * 3) + 1;
      }
      else {
        N = N / 2;
      }
      counter++;
      System.out.println(N);
    }
    /**
    3. Outputting Repeat Count Variable
    */
    System.out.print("The loop repeated " + counter + " times.");
  }
}