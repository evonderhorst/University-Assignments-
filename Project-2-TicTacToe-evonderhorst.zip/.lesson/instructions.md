# Project 2 - Tic Tac Toe
## Overview
Write a program for two players to play Tic-Tac-Toe. The board should be displayed in the console, with empty board spaces represented by an underscore ("_") character. As each player takes their turn, they should be asked which row and column to place their marker, and the board should be updated and printed with the appropriate change. 

The game should end when either player gets three symbols in a row, column, or diagonal; or, it should end when all spaces are filled but neither player has won yet.

## Specifications
This program should start by printing an empty Tic-Tac-Toe board:
```
- - -
- - -
- - -
```

Next, the "X" player should go first. The program should ask for the row and column in which to place the marker (start counting rows and columns from 1).

For example, to place the "X" in the center, the output and input would look like this: 

```
Player X's turn!
Enter the row: 2
Enter the column: 2
- - -
- X -
- - -
```

The state of the board should be stored in a 2-dimensional array.

After every turn, the program should check to see if one of the players has won, or to report a draw.

Your project should only use one class file, called **TicTacToe**, which contains all the subroutines used by the program.

Be sure to clearly document your code!

Any and all user input should be validated! Do not let the users try to overwrite the other player's pieces, or place a piece in an invalid board cell.

# Submission
Be sure to test different situations, test how the program handles erroneous input and different edge cases.

Make sure to turn in a few test runs of your program in text files.

Upload your project files to MyClasses.

Submit here on replit when you're finished.




