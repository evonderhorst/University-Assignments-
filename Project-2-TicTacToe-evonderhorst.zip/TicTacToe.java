/**
Erich Vonderhorst
Project 2
COSC 117
11/04/2022

This program creates a medium for a game of Tic-Tac-Toe between two players. 
*/
import java.util.Scanner;
class TicTacToe {
  public static Scanner stdin = new Scanner(System.in); //Scanner object
  public static char[][] board = { //2d array that represents an empty game board for Tic-Tac-Toe
      {'_','_','_'},
      {'_','_','_'},
      {'_','_','_'}
    };
  //Main Method
  public static void main(String[] args) {
    boolean win = false; //Boolean value to keep track of whether either player won or not 
    char winner = ' '; //Variable used to declare the winner and keep track of who is playing
    int count = 0; //Variable used to count the number of turns passed
    printBoard(); //Displaying the empty board
    //Main Game Loop
    while (win == false) {
      winner = 'X'; //If "win" is declared true by the method in the next line, the assigned player is reported as the winner
      win = player(winner);
      if (win == true) {
        break;
      }
      count++;
      if (count == 9) { //If "win" is not declared true within nine rounds (most rounds possible in a game) then a draw is reported and the loop is broken
        System.out.print("The game has ended in a draw!");
        break;
      }
      winner = 'O';
      win = player(winner);
      count++;
    }
    if (win == true) {
      System.out.println("Player " + winner + " has won the game!"); //Outputting the victor
    }
    stdin.close(); 
  }
  //Method for Each Player's Turn
  public static boolean player (char player) {
    System.out.println("\nPlayer " + player + "'s turn!");
    while (true) {
      System.out.print("Enter a row: ");
      //Getting a Row Value from User Input
      int row = inputAssign() - 1;
      stdin.nextLine();
      System.out.print("Enter a column: ");
      //Getting a Column Value from User Input
      int column = inputAssign() - 1;
      stdin.nextLine();
      //Checking to See if Space is Already Taken Up
      if (board[row][column] != 'X' && board[row][column] != 'O') {
        board[row][column] = player;
        //Printing Out the Game Board
        printBoard();
        //Checking to See if Either Player Won
        return boardCheck(player);
      }
      else {
        System.out.println("Spot already taken.");
      }
    }
  }
  //Method for Checking if Either Player Won or Not
  public static boolean boardCheck(char player) {
    for (int x = 0; x < board.length; x++) {
      //Checking for Horizontal Rows of Three
      if (board[x][0] == player && board[x][1] == player && board[x][2] == player) {
        return true;
      }
      //Checking for Vertical Rows of Three
      if (board[0][x] == player && board[1][x] == player && board[2][x] == player) {
        return true;
      }
    }
    //Checking for Diagonal Rows of Three
    if (board[1][1] == player && board[2][0] == player && board[0][2] == player) {
      return true;
    }
    if (board[1][1] == player && board[0][0] == player && board[2][2] == player) {
      return true;
    }
    return false;
  }
  //Method for Assigning Values to Variables With User Input and Input Validation
  public static int inputAssign() {
    while (true) {
      if (stdin.hasNextInt()) {
        int x = stdin.nextInt();
        if (x > 0 && x <= 3) {
          return x;
        }
        else{
          System.out.print("Enter a valid value: ");
          stdin.nextLine();
        }
      }
      else {
        System.out.print("Enter a valid value: ");
        stdin.nextLine();
      }
    }
  }
  //Method Used to Print the Game Board to the Console
  public static void printBoard() {
    for (int x = 0; x < board.length; x++) {
      for (int y = 0; y < board[x].length; y++) {
        System.out.print(board[x][y] + " ");
      }
      System.out.print("\n");
    }
  }
}