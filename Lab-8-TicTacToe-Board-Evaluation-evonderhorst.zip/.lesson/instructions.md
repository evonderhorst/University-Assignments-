# Objectives
1. Practice using subroutines
2. Practice using file input/output
3. Practice using multi-dimensional arrays

# Pre-reading
Recall that, in Java, we can do _multi-dimensional_ arrays; we can think of these as "arrays of arrays", and that is reflected by the syntax. For example, in this lab you will create and use a two-dimensional array of characters, with type: `char[][]`. The array will hold character values of a Tic-Tac-Toe board. If you were to hard-code one of these two-dimensional arrays, it would look like

```java
char[][] board = { // Will begin the "outer" array
  {'X', '_', '_'}, // row 0
  {'_', 'O', 'X'}, // row 1
  {'O', 'X', '_'} // row 2, no comma!
};
```

With this setup, we can use a "double index" to access a single element. Using the example variable defined above:

```java
System.out.println("Center is: " + board[1][1]); // Center: 0
```

Recall how array indexingworks: the first [1] says to look at hte array / row with index 1, which is the character array {'_', 'O', 'X'}. Then if we look at index 1 of *that* array, we get the 'O' character in the center of the board. Similarly, board[0][2] would evaluate to the character '_', an underscore, which represents an empty board space. You can likely see that the bottom-right coordinates are board[2][2], the top-left is board[0][0], the top-right is board[0][2], the bottom-left is board[2][0], etc. Of course, one could re-interpret the order of the characters in a column-wise fashion rather than row-wise, but there's no point in complicating things that way just yet!

Recall the example we did before to print such a two-dimensional array:

```java
// good time to use more logical loop variable names than "i"!
// the outer-loop will walk down the rows as "row" increases
for(int row=0; row<board.length; row++){
  // with the row index fixed, print out the value in each column:
  // note that we use board[row].length as the limit!
  for(int col=0; col<board[row].length; col++){
  // print out the cell value followed by a space, don't break the line
    System.out.print(board[row][col] + " ");
  }
// break the line after finished with a whole row
System.out.println();
}
```

# Tasks
### 1.
For this lab, you will practice reading in files, and working with 2-dimensional arrays. As an added bonus, this will get you started on some aspects of Project 2 and give an opportunity to tie multiple aspects of the course together!

### 2. Write a program that loops the following processs until the user decides to stop
1. Ask the user for a file to read in, which should contain some text that represents the state of a Tic-Tac-Toe board. Be sure to test if the file exists! (With a try...catch block, if there is an error, re-prompt the user for a valid file)
2. Read this into a two-dimensional array (type: char[][]) and then pass the array to a subroutine which will print out to the user for confirmation
3. Next, use another function to check whether there is a winner in the game. Be sure to check all cases: horizontal (rows), vertical (columns), or the diagonals. If there is a winner, report whether it is the "X" or "O" player.

   Optionally, you may find it helpful to add extra "helper" functions to check a single row, column, or diagonal for a win. For example, you could write a function called `checkRow(int i)` that takes the row number (0,1,2) and checks only that row to see if there is a winner there. Then you could just call that function three times and look at the results.

### 3. Create several different input files to test your program with. 
The format of the Tic-Tac-Toe files will have the following structure

```
X _ O
X _ _
O _ _
```

Where each row of the board is separated by a newline character ('\n') and each symbol within a row has a space between it and hte next. The underscore characters ('_') represent an unused board space. Other example input files might look like:

```
_ _ _
_ X _
_ O _
```

or 

```
X O X
_ X O
X O X
```

**Be sure to test your program on at least one of each case!**

### 4. An example run of the program might look like
```
Welcome to the Tic-Tac-Toe winner check program!
Please enter the name of a file to check: input1.txt
Thank you! Here is the board to check:
X _ O
X _ _
O _ _
Nobody wins yet!
Test another (y/n)? y
Please enter the name of a file to check: input2.txt
Thank you! Here is the board to check:
X O X
_ X O
X O X
X is the winner of this game!
Test another (y/n)? n
Goodbye!
```

# Submission
Submit your source code to MyClasses assignment and submit here on replit!