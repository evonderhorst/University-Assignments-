/**
Erich Vonderhorst
Lab 8
COSC 117
11/07/2022

This program practices reading in files, working with 2-dimensional arrays, and using 
subroutines by allowing the user to input the name of a file containing a representation of 
a Tic-Tac-Toe board which is then opened and checked to see if there is a winner in said 
representation. This process loops until the user ends the program. 
*/
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
class WinCheck {
  public static Scanner fileOpen; //Scanner used to read file contents
  public static Scanner stdin = new Scanner (System.in); //Scanner used to read user input
  public static void main(String[] args) {
    char[][] board = new char[3][3]; //Array that stores the board characters
    boolean again = false; //Condition used to end main loop if user doesn't want to continue
    //Main Loop
    while (again == false) {
      //Getting a File Name From User Input
      System.out.print("Enter a file name to open: ");
      while (again == false) {
        //Checking if File is Real
        try {
          fileOpen = new Scanner(new File(stdin.nextLine()));
          break;
        }
        catch (FileNotFoundException e) {
          System.out.print("File not found! Enter a valid file name: ");
        }
      }
      //Filling In the 2D Array
      int x = 0;
      while (fileOpen.hasNextLine()) {
        String line = fileOpen.nextLine();
        line = line.replace(" ", "");
        board[x] = line.toCharArray();
        x++;  
      }
      //Outputting the Board
      System.out.println("Here is the board: ");
      printBoard(board);
      //Checking for a Winner
      char winner = boardCheck(board);
      if (winner == 'N') {
        System.out.println("This game has no winner.");
      }
      else {
        System.out.println(winner + " wins this game!");
      }
      //Asking User if They Want to End the Program
      System.out.print("Would you like to test another file (1 for yes and 2 for no)?: ");
      while (true) {
        if (stdin.hasNextInt()) { 
          int answer = stdin.nextInt();
          if (answer == 1) {
            stdin.nextLine();
            break;
          }
          else if (answer == 2) {
            again = true;
          }
          else {
            System.out.print("Please type 1 or 2: ");
            stdin.nextLine();
          }
        }    
        else {
          System.out.print("Please type 1 or 2: ");
          stdin.nextLine();
        }
      }
    }
    fileOpen.close();
    stdin.close();
  }
  //Method for Checking for a Winner
  public static char boardCheck(char[][] board) {
    //Checking for Diagonal Rows of Three
    if (board[1][1] == 'X' && board[2][0] == 'X' && board[0][2] == 'X') {
      return 'X';
    }
    if (board[1][1] == 'X' && board[0][0] == 'X' && board[2][2] == 'X') {
      return 'X';
    }
    for (int x = 0; x < board.length; x++) {
      //Checking for Horizontal Rows of Three
      if (board[x][0] == 'X' && board[x][1] == 'X' && board[x][2] == 'X') {
        return 'X';
      }
      if (board[x][0] == 'O' && board[x][1] == 'O' && board[x][2] == 'O') {
        return 'O';
      }
      //Checking for Vertical Rows of Three
      if (board[0][x] == 'X' && board[1][x] == 'X' && board[2][x] == 'X') {
        return 'X';
      }
      if (board[0][x] == 'O' && board[1][x] == 'O' && board[2][x] == 'O') {
        return 'O';
      }
    }
    return 'N';
  }
  //Method for Printing Out Board
  public static void printBoard(char[][] board) {
    for (int x = 0; x < board.length; x++) {
      for (int y = 0; y < board[x].length; y++) {
        System.out.print(board[x][y] + " ");
      }
      System.out.print("\n");
    }
  }
}