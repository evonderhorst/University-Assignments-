/**
Erich Vonderhorst 
Lab 7
COSC 117
10/30/2022

The purpose of this program is to practice using file input and the manipulation of ASCII values by allowing the user to encrypt a message with a specified shift and save it to a file or decrypt a message from a chosen file using a specified shift. 
*/
import java.io.PrintWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
class Message {
  //Main Body Function
  public static void main(String[] args) {
    Scanner stdin = new Scanner(System.in);
    //Encrypt or Decrypt
    System.out.println("Enter '1' to encode a message or '2' to decode a message: ");
    while (true) {
      if (stdin.hasNextInt()) {
        int selection = stdin.nextInt();
        if (selection == 1) {
          encrypt(); //Calling encrypt function
          break;
        }
        else if (selection == 2) {
          decrypt(); //Calling decrypt function
          break;
        }
      }
      else {
        System.out.println("Please enter a valid input. ");
        stdin.nextLine();
      }  
    }
    stdin.close();
  }
  //Encryption Function
  public static void encrypt() {
    Scanner stdin = new Scanner(System.in);
    //Getting the Message and Separating Into an Array
    System.out.println("Enter the message you want to encode: ");
    String message = stdin.nextLine();
    char[] messageChar = message.toCharArray();
    //Getting a Shift Value
    System.out.println("Enter a shift value: ");
    int shift = 0;
    while (true) {
      if (stdin.hasNextInt()) {
        shift = stdin.nextInt();
        break;
      }
      else {
        System.out.println("Enter a valid shift value."); 
        stdin.nextLine();
      }
    }
    //Encrypting the Message
    for (int x = 0; x < messageChar.length; x++) {
      //Shifting Uppercase Letters
      if (Character.isUpperCase(messageChar[x])) {
        messageChar[x] += shift;
        //Wrap-Around 
        if (messageChar[x] > 90) {
          while (messageChar[x] > 90) {
            messageChar[x] -= 26;
          }
        }
      }
      //Shifting Lowercase Letters
      else if (Character.isLowerCase(messageChar[x])) {
        messageChar[x] += shift;
        //Wrap-Around
        if (messageChar[x] > 122) {
          while (messageChar[x] > 122) {
            messageChar[x] -= 26;
          }
        }
      }
      else {
        continue;
      }
    }
    //Outputting the Encrypted Message
    System.out.print("Your encrypted message is: ");
    for (int y = 0; y < messageChar.length; y++) {
      System.out.print(messageChar[y]);
    }
    //Saving Message to a File
    PrintWriter messageFile;
    System.out.println("\nEnter the file you want to store this message in: ");
    String saveFile = stdin.nextLine();
    saveFile = stdin.nextLine();
    try {
      messageFile = new PrintWriter(saveFile);
      messageFile = new PrintWriter(new File(saveFile));
      for (int z = 0; z < messageChar.length; z++) {
      messageFile.print(messageChar[z]);
      }
      messageFile.close();
    }
    catch (FileNotFoundException e) {
      System.out.println("File not found.");
      return;
    }
    stdin.close();
  }
  //Decryption Function
  public static void decrypt() {
    Scanner stdin = new Scanner(System.in);
    Scanner messageFile;
    String message;
    //Getting the Encrypted Message From a File
    System.out.println("Enter the file that you want to decrypt: ");
    String openFile = stdin.nextLine();
    try {
      messageFile = new Scanner(new File (openFile));
      message = messageFile.nextLine();
      messageFile.close();
    }
    catch (FileNotFoundException e) {
      System.out.println("File not found.");
      return;
    }
    System.out.println("The encrypted message is: " + message);
    int shift = 0;
    System.out.println("Enter a shift value: ");
    while (true) {
      if (stdin.hasNextInt()) {
        shift = stdin.nextInt();
        break;
      }
      else {
        System.out.println("Enter a valid shift value."); 
        stdin.nextLine();
      }
    }
    //Decrypting the Message
    char[] messageChars = message.toCharArray();
    for (int x = 0; x < messageChars.length; x++) {
      //Shifting Uppercase Letters
      if (Character.isUpperCase(messageChars[x])) {
        messageChars[x] -= shift;
        //Wrap-Around 
        if (messageChars[x] < 65) {
          while (messageChars[x] < 65) {
            messageChars[x] += 26;
          }
        }
      }
      //Shifting Lowercase Letters
      else if (Character.isLowerCase(messageChars[x])) {
        messageChars[x] -= shift;
        //Wrap-Around
        if (messageChars[x] < 97) {
          while (messageChars[x] < 97) {
            messageChars[x] += 26;
          }
        }
      }
      else {
        continue;
      }
    }
    //Outputting Decrypted Message
    System.out.print("The decrypted message is: ");
    for (int y = 0; y < messageChars.length; y++) {
      System.out.print(messageChars[y]);
    }
    stdin.close();
  }
}