# Objectives
1. Practice with file input
2. Practice with manipulating ASCII values

# Tasks
In this lab you will practice more with the Caesar cipher algorithm, but with file input and output!

### 1. Prompt the user to see if they wish to encode or decode a message
1. Ask them to enter the message and store it in a `String` variable
2. Once the message is entered, ask them for a "shift" integer, sim ilar to lab 6.
3. Using that shift, move all alphabetical characters in the message (i.e. excluding spaces and punctuation) using `char` and `int` arithmetic. Be sure to account for alphabetical wrap-around!
4. Ask the user for a filename (nospaces), then output the encrypted message to that file on a single line. Then you may terminate the program, or loop back to the beginning.

### 2. Some general notes to consider:
1. Take into account both upper- and lower-case characters! after shifting for encode or decoding, the case should be preserved!
2. Do not shift punctuation / spaces

# Example run 1
```
Welcome to your personal message encryption/decryption program!
Would you like to Encode (E) or Decode (D) a message? E
Great! Please enter your message below:
One if by land, two if by sea.
Now enter your shift amount (an integer or a character relative to A): D
You've selected a shift of 3. Processing...
Your encrypted message is: Rqh li eb odqg, wzr li eb vhd.
Please enter the file to store this message: secret.txt
Saving...Done!
Goodbye!
```

```
Welcome to your personal message encryption/decryption program!
Would you like to Encode (E) or Decode (D) a message? D
Great! Please enter the file you want to decrypt: secret.txt
Loading the file...
The encrypted message is: Rqh li eb odqg, wzr li eb vhd.
Enter the shift (an integer or character relative to A): D
Decrypting...
The decrypted message is:
One if by land, two if by sea.
Goodbye!
```

# Submission
Upload your source code, properly documented, to the course MyClasses page.

Submit your code here on replit.