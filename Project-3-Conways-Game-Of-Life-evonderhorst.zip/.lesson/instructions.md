# Conways game of life
## Description
You will write a program to execute Conway's "Game of Life". This is a zero-player game / simulation, meaning it runs itself, based on some initial configuration.

The game is played on a 2-D grid, each space representing a "cell" in a system. 
Cells can either be living or dead. 
The system evolves according to the following rules:
1. If a living cell has 0 or 1 living neighbors, it dies from loneliness
2. If a living cell has 2 or 3 living neighbors, it survives the current generation
3. If a living cell has more than 3 living neighbors, it dies from overpopulation
4. If a **dead** cell has ***exactly*** three living neighbors, it becomes alive, as if from reproduction

The simulation will continue until the user interrupts the program.

## Example simulation
![gol](assets/gameoflife.gif)

## Specifications
### Your program should use 1 class file

### Cells
Keep track of the grid of cells by using a class variable that is a two-dimensional array of boolean values, where `true` means that a cell is alive, and `false` denotes a dead cell.

### Seeding the cells
To start the system with some "live" cells, use `Math.random()` to randomly set some cells to living at the start. You can do this by simply checking if Math.random() > 0.5, and if it is, set the cell to be true, false otherwise. This will make each cell have a 50/50 chance of starting off as alive, so you may way to modify the choosen probability in the above expression to get a more interesting result.

### Updating the state
Write a subroutine called `updateCells` that *only* calculates the status of the board after one "round" or "tick" of the game. i.e. loop through every cell and figure out whether it should be alive or dead in the next iteration of the game. 

**Hint**

Use a *copy* of the board to store the new state of the cells, then copy it back into the original board. Think about why you need to do it this way instead of modifying the original board directly!

### Representing living and dead cells
Choose some character to represent living cells, and another character for dead cells. 

I choose empty spaces for dead cells, and X for living cells. But you're free to choose whatever you want.

### Documentation
Be sure to thoroughly comment your code.

### Sleep between drawing
We can sleep between draws by using the `Thread.sleep(1000)` function.

The number argument that it takes in, in this case `1000`, is the number in milliseconds that you want your program to sleep for. 1000ms = 1s.

You will need to wrap this in a try/catch since it can throw an exception

```java
try {
  while (true) {
    // Do some stuff....
    // ... 
    
    Thread.sleep(500); // Will sleep for 0.5s

    // Do some more stuff
  }
}
catch (Exception e) {
  
}
```

### Clearing the console between prints
You can clear the console inbetween draws/printing, which would make it appear as if your console were **updating** rather than printing thousands of lines!

We can do this by **printing** some **ascii escape codes**.

```java
// This line will completely clear the console!
System.out.print("\033[H\033[2J");
```



## Submission
Upload your project files (for this project only!) to the course canvas system

Submit the project here on replit.

## Bonus
You may or may not add the following features for a maximum of 5 extra points each:
- Allow the user to input the desired grid before the game begins
- Write the **updateCells** subroutine in a general-enough way that one can easily change the parameters of the game: e.g. set it so that a cell must have 4, rather than 3, living neighbors to be "born."