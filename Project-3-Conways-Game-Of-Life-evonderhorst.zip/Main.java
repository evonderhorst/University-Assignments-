/**
Erich Vonderhorst
COSC 117
Project 3 - Conway's Game of Life
12/06/2022

This program simulates Conway's game of life and its associated rules within a 2d grid array composed of "cells" which are marked as "alive" or "dead" according to said rules. Multiple settings that determine how the simulation is played out are below for the user to customize such as the symbols for dead and alive cells, the color of output text, the dimensions of the grid, etc.
*/


class Main {
//---------------------------------------------------------------------------------------------
//--------------------------------Variables and User Settings----------------------------------
//---------------------------------------------------------------------------------------------

  //Set the number of rows and columns the grid used in the simulation will have:
  static int gridRows = 20;
  static int gridColumns = 20;

  //Set the probability that a cell will be randomly seeded as alive (the program checks to see if randomly generated value is lower than this variable and, if so, seeds a cell as false):
  static double seedChance = 0.5;

  //Set the text character that dead and living cells will appear as in the simulation:
  static char deadSymbol = 'Z';
  static char aliveSymbol = 'X';

  //Set the color that dead and living cells will appear in| choose from black, red, green, yellow, blue, purple, or cyan (leave blank for default color of white, all erroneous input defaults to white):
  static String deadColor = "cyan";
  static String liveColor = "black";

  //Set the distance between each cell (xSeparation is the number of spaces between cells in the same row and ySeparation is the number of blank lines between each row of cells):
  static int xSeparation = 0;
  static int ySeparation = 0;

  //Set the rate at which the simulation updates the grid with new living and dead cells (time (miliseconds) between the printing of each new iteration):
  static int refreshRate = 1000;

  //Set the number of living cells surrounding a dead cell needed for it to become alive, default is 3:
  static int birthNeighbors = 3;

  //Set the maximum number of living cells that can surround a living cell so that it survives in the next iteration without it turning dead from overpopulation, default is 3:
  static int maxLiveNeighbors = 3;

  //Set the minimum number of neighors a living cell needs to survive in the next iteration, default is 2:
  static int minLiveNeighbors = 2;

  //Set whether or not you want to use a custom grid and, if you do, set the cells in the grid below as living or dead (true or false) (feel free to add or remove rows and colums, just make sure all rows are the same length):
  static boolean useCustomGrid = false;
  static boolean[][] custom = {
    {false, false, false, false, false, false, false, false, false, false},
    {false, false, false, false, false, false, false, false, false, false},
    {false, false, false, false, false, false, false, false, false, false},
    {false, false, false, false, false, false, false, false, false, false},
    {false, false, false, false, false, false, false, false, false, false},
    {false, false, false, false, false, false, false, false, false, false},
    {false, false, false, false, false, false, false, false, false, false},
    {false, false, false, false, false, false, false, false, false, false},
    {false, false, false, false, false, false, false, false, false, false},
    {false, false, false, false, false, false, false, false, false, false}
    };

//---------------------------------------------------------------------------------------------
//---------------------------------------Main Method-------------------------------------------
//---------------------------------------------------------------------------------------------

  public static void main(String[] args) {
    
    //Overall Program
    try {
      
      boolean[][] grid; //Grid used for the simulation
      
      if (useCustomGrid) {
        grid = customCheck(); //Checking to see if a custom grid is being used and, if so, if all the rows are of equal length
      }
        
      else {
        grid = grid(); //In the absence of a custom grid, a random one is assigned and cells are seeded
      }

      //When the grid has been prepared, the simulation is carried out within this loop
      while (true) {
        printGrid(grid); //Prints out the grid with respect to the current state of each cell
        grid = updateCells(grid); //Determines which cells should be live or dead in the next iteration of the grid and updates them
      }
    }

    //General error message
    catch (Exception e) {
      System.out.println("An error has occurred! Check the settings and try running the program again.");
    }
  }


//---------------------------------------------------------------------------------------------
//--------------------------------------Grid Methods-------------------------------------------
//---------------------------------------------------------------------------------------------
  
  //Grid generation and cell seeding method
  public static boolean[][] grid() {
    boolean[][] grid = new boolean[gridRows][gridColumns]; //Grid that will be returned through the method

    //Seeding the cells (randomly determining which should be live or dead in the initial iteration of the grid based on the probability set by the user)
    for (int i = 0; i < grid.length; i++) {
      for (int x = 0; x < grid[i].length; x++) {
        double seed = (Math.random());
        if (seed < seedChance) { //Comparing random value to user-defined probability/ threshold
          grid[i][x] = true; //Cell is live
        }
        else {
          grid[i][x] = false; //Cell is dead
        }
      }
    }
    return grid; //Grid has been seeded and is ready to be used in the simulation
  }

  //Cell updating method
  public static boolean[][] updateCells(boolean[][] grid) {
    boolean[][] tempGrid = new boolean[gridRows][gridColumns]; //Temporary grid for updating
    for (int i = 0; i < gridRows; i++) {
      for (int x = 0; x < gridColumns; x++) {
        tempGrid[i][x] = surround(grid,i,x); //Determining if each cell in the updated grid should be live or dead through the surround method
      }
    }
    return tempGrid; //All the cells have been updated and the new grid is returned for replacing the previous iteration
  }

  //Reading surrounding cells method for cell updating method
  public static boolean surround(boolean[][] grid, int y, int x) {
    int liveNeighbors = 0; //Variable for counting the number of living neighbors in the surrounding cells
    
    //Looping over the surrounding 8 cells
    for (int i = y - 1; i <= y + 1; i++) { 
      for (int n = x - 1; n <= x + 1; n++) {
        try {
          //Skipping over the current cell index that the method is being called to update
          if (n == x && i == y) {
            continue;
          }
          else {
            //Counting the number of live neighbor cells
            if (grid[i][n] == true) {
              liveNeighbors++;
            }
          }
        }
        //In the case that a cell doesn't have 8 cells surrounding it (because its on an edge or corner), the program will continue
        catch (IndexOutOfBoundsException e) {
          continue;
        }
      }
    }

    //If the cell being updated is dead:
    
    //check to see if it has the exact number of live neighbors needed to be born
    if (grid[y][x] == false) {
      if (liveNeighbors == birthNeighbors) {
        return true; //Update cell as live if it has the number of neighbors needed to be born 
      }
      return false; //Cell remains dead if it doesn't have enough live neighbors
    }

      
    //If the cell being updated is alive:

    //Check to see if the cell dies from not having enough live neighbors
    else if (liveNeighbors < minLiveNeighbors) {
      return false; //The cell is updated as dead
    }
    //Check to see if the number of neighbors is enough for survival but not enough to lead to overpopulation
    else if (liveNeighbors >= minLiveNeighbors && liveNeighbors <= maxLiveNeighbors) {
      return true; //Cell survives and remains alive
    }
    //In the case that the cell has too many live neighbors:
    return false; //The is updated as dead
  }
  
  //Grid printing method
  public static void printGrid(boolean[][] grid) {
    try {
      Thread.sleep(refreshRate); //Delaying the next console print by a number of miliseconds entered by the user
      System.out.print("\033[H\033[2J"); //Clearing the console output
      
      for (int i = 0; i < grid.length; i++) {
        for (int x = 0; x < grid[i].length; x++) {
          if (grid[i][x] == true) {
            System.out.print(color(liveColor) + aliveSymbol + "\033[0m"); //Printing out live cells with the color and symbol chosen by the user
          }
          else {
            System.out.print(color(deadColor) + deadSymbol + "\033[0m"); //Printing out dead cells with the color and symbol chosen by the user
          }
          //Spacing between printed symbols based on a variable set by user
          for (int y = 0; y < xSeparation; y++) {
              System.out.print(" ");
          }
        }
        
        System.out.println(""); //Starting a new line to print
        //Skipping over number of lines for spacing based on a variable set by user
        for (int y = 0; y < ySeparation; y++) {
          System.out.println("");
        }
      }
    }
      
    catch (Exception e) {
      System.out.print("An error ocurred! Check the settings and try running the program again."); //Error message for if the grid fails to print
      System.exit(0);
    }
  }
  

//---------------------------------------------------------------------------------------------
//-------------------------------------Other Methods-------------------------------------------
//---------------------------------------------------------------------------------------------

  //Custom grid validation method
  public static boolean[][] customCheck() {
    boolean valid = true; //Flag variable used to determine if the custom grid is valid for use

    //Checking to see if all rows are the same length
    for (int i = 1; i < custom.length; i++) {
      if (custom[0].length != custom[i].length) {
        valid = false; //Variable is flagged as false and the loop is broken if lines aren't the same length
        break;
      }
    }

    //If the flag variable picked up that the custom grid is invalid:
    if (valid == false) {
      try {
        //Giving an error message
        System.out.println("The rows in your custom grid weren't the same length. \nDefaulting to random grid...");
        Thread.sleep(4000); //Displaying the message for 4 seconds
        System.out.print("\033[H\033[2J"); //Clearing the console after the message is printed for four seconds
        return grid(); //Defaulting to generating a random grid if custom grid is invalid and returning it
      }
        
      catch (Exception e) {
        System.out.println("An error has occurred! Check the settings and try running the program again."); //Message for if an unexpected error occurs
      }
    }

    //If the custom array is deemed valid (the flag variable remains true)

    //Update grid dimensions to those of the custom grid
    gridRows = custom.length; 
    gridColumns = custom[0].length;
    return custom; //The custom grid can be used and is returned
  }

  //Output color method
  public static String color(String color) {
    //Checking which color was specified by the user and returning the corresponding ANSI color code so it can be concatenated with the cell's specified symbol and the ANSI reset code
    if (color == "black" || color == "Black") {
      return "\033[0;30m";
    }
    else if (color == "red" || color == "Red") {
      return "\033[0;31m";
    }
    else if (color == "green" || color == "Green") {
      return "\033[0;32m";
    }
    else if (color == "yellow" || color == "Yellow") {
      return "\033[0;33m";
    }
    else if (color == "blue" || color == "Blue") {
      return "\033[0;34m";
    }
    else if (color == "purple" || color == "Purple") {
      return "\033[0;35m";
    }
    else if (color == "cyan" || color == "Cyan") {
      return "\033[0;36m";
    }

    //If no color or an invalid color is specified, return no text for concatenation
    return "";
  }

}