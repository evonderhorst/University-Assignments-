# Instructions  

## General lab requirements
1. Review sections 2.1 and 2.2 of Eck text
2. Name each file after the problem
    - e.g. HelloWorld problem = HelloWorld.java
    - e.g. MyInfo problem = MyInfo.java
4. All of your programs should include a comment block at the top of each file that includes, at a minimum,
    - the assignment name (e.g. Lab 1)
    - problem name / number if the lab has more than one
    - your name
    - the course number
    - the date
    - It is also good practice to include a brief description of the program and the date it was written and/or updated.

```java
/**
 * Lab 1 - Problem 1
 * Alan Turing
 * COSC 117
 * 01/01/2022
 * 
 * This program demonstrates basic concepts of variables,
 * functions, and control structures.
*/

public class HelloWorld {
  /**
  * The main function prints "Hello, World!" to standard output.
  */
  public static void main(String[] args) {
    System.out.println("Hello, World!");
  }
}
```

## 1. Objectives
1. Develop a basic familiarity with a code editor and compilers.
2. Create a basic "Hello World" application
3. Become familiar with the concept of variables and basic function calls.

## 2. Problems
### Hello World
Create the basic "Hello World" program shown above, commenting appropriately and making sure it compiles and runs without error. Make sure you store this problem in a new file named after this problem (HelloWorld.java)

This editor only allows for the Main.java file to be executed by the **Run** button. So instead, we'll compile our programs ourselves in the console or shell given.

To compile and test a Java program, such as HelloWorld.java, use the following steps
- Open a new shell / console in a new tab or pane.
- use the command ``javac HelloWorld.java`` to compile the source code into java byte code. This will create a "HelloWorld.class" file.
- Then to run your compiled program, use the command ``java HelloWorld``, leaving off any file extension.

To compile and test other Java programs, perform the same actions, only changing the HelloWorld to the name of your file.

### MyInfo
Modify your program to print your name, address, age, and experiment with other things it could display.

For each piece of data, try storing it in a variable declared in the ``main`` function, then pass that variable to the ``println`` function. 

See what happens with different data types: double, int, char, bool

For example
```java
int myAge = 20; // is using an int appropriate here?
System.out.println(myAge);
```

### Questions
In the comments, answer the following questions
- What happens if you use ``print`` instead of ``println`` in your program?
- What data types did you choose for your data, and why? Are there other appropriate choices?

## 3. Turn in
Turning in these asignments is done in two parts.

1. Click the "Submit" button here so I can view that it's compilable and work through any errors with you.

2. Download the files by downloading the zip from the menu, and submit this lab or assignment to MyClasses.

If you decide to code on an external editor, that's fine. Just copy the code into here, make sure it runs, and don't forget to submit in MyClasses.