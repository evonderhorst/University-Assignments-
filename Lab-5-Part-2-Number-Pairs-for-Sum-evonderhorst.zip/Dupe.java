/**
Erich Vonderhorst
Lab 5 Problem 1
COSC 117
10/10/2022

This program looks for duplicate values in an array composed by integers from user input.
*/
import java.util.Scanner;
class Dupe {
  public static void main(String[] args) {
    Scanner stdin = new Scanner(System.in);
    int count = 0; //Variable used to store the amount of integers entered
    int[] valueArray = new int[20]; //Array used to hold values input by user
    int value = 0; //Variable used to temporarily store user input integers before being put into the value array
    int dupeCount = 0; //Variable used to count the number of duplicated values found
    int[] dupeArray = new int[20]; //Array used to store the found duplicated values
    //Getting the integers
    System.out.println("Enter up to 20 integers betweeen 0 and 100. Enter a negative value or a value above 100 to stop: ");
    while (true) {
      if (stdin.hasNextInt()) {
        value = stdin.nextInt();
        if (value < 0 || value > 100) {
          break;
        }
        else {
          valueArray[count] = value;
          count++;
          if (count == 20) {
            break;
          }
        }
      }
      else {
        System.out.println("Please enter a valid integer.");
      }
      stdin.nextLine();
    }
    //Looking for duplicates
    for (int i = 0; i < count; i++) {
      for (int x = i + 1; x < count; x++ ) {
        if (valueArray[i] == valueArray[x]) {
          dupeArray[dupeCount] = valueArray[i];
          dupeCount++;
        }
      }
    }
    //Displaying results
    System.out.println("Number of duplicates found: " + dupeCount);
    System.out.print("The duplicated values were: ");
    for (int y = 0; y < dupeCount; y++) {
      System.out.print(dupeArray[y] + " ");
    }
    stdin.close();
  }
}