# Find duplicates in an array
## Overview
Read in an array, up to 20 integers long, which contain elements from **0 to 100**. If the user inputs a negative number, you can assume they are done giving input.

You need to find and print all elements occuring more than once in the given array in a sorted manner. If no such element is found, print that instead.

## Example run 1
```
Enter up to 20 integers between 0 to 100 (-1 stops)...
1
72
32
14
72
0
-1
======
Number of duplicates found: 1
Duplicates: 72
```

## Example run 2
```
Enter up to 20 integers between 0 to 100 (-1 stops)...
1
72
32
72
1
9
7
5
72
-1
======
Number of duplicates found: 3
Duplicates: 1 72
```

## Example run 3
```
Enter up to 20 integers between 0 to 100 (-1 stops)...
1
72
32
1
9
7
5
72
0
2
3
4
5
6
7
8
9
10
11
12
======
Number of duplicates found: 5
Duplicates: 1 5 7 9 72 
```